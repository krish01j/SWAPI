import {Component} from 'react'

class Home extends Component {


     getData = async event =>{
        

    const url = 'https://swapi.dev/api/people'
    const options = {
      method: 'GET',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    
  }

  getData()

    

  render() {
    return (
      <div>
        <h1>the details of SWAPI database</h1>
        {data}
      </div>
    )
  }
}
export default Home
